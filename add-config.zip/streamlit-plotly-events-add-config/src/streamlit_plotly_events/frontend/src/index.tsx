import React from "react"
import ReactDOM from "react-dom"
import StreamlitPlotlyEventsComponent from "./StreamlitPlotlyEventsComponent"

ReactDOM.render(
  <React.StrictMode>
    <StreamlitPlotlyEventsComponent />
  </React.StrictMode>,
  document.getElementById("root")
)
